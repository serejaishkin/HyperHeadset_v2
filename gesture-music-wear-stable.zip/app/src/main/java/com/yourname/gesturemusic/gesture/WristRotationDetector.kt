package com.yourname.gesturemusic.gesture

import kotlin.math.abs

class WristRotationDetector(
    private val angleThresholdDegrees: Float = 22f,
    private val minAngularSpeed: Float = 1.5f,
    private val minDurationMs: Long = 150L,
    private val cooldownMs: Long = 1500L,
    private val windowMs: Long = 400L,
    private val idleThreshold: Float = 0.3f,
    private val idleTimeoutMs: Long = 200L,
    private val antiNoiseAccY: Float = 15f
) : GestureDetector {

    private val alpha = 0.8f
    private var filteredGyroX = 0f
    private val samples = mutableListOf<Sample>()
    private var lastGestureTime = 0L
    private var gestureStartTime = 0L
    private var idleStartTime = 0L
    private var inGesture = false

    private data class Sample(val timestamp: Long, val gyroX: Float, val linAccY: Float)

    override fun process(timestamp: Long, gyroX: Float, gyroY: Float, gyroZ: Float,
                         linAccX: Float, linAccY: Float, linAccZ: Float): GestureType? {
        if (abs(linAccY) > antiNoiseAccY) { resetWindow(); return null }
        filteredGyroX = alpha * filteredGyroX + (1 - alpha) * gyroX
        samples.removeAll { timestamp - it.timestamp > windowMs }
        samples.add(Sample(timestamp, filteredGyroX, linAccY))
        if (abs(filteredGyroX) < idleThreshold) {
            if (idleStartTime == 0L) idleStartTime = timestamp
            if (timestamp - idleStartTime > idleTimeoutMs) { resetWindow(); return null }
        } else { idleStartTime = 0L }
        if (timestamp - lastGestureTime < cooldownMs) return null
        if (samples.size < 2) return null
        val maxAngularSpeed = samples.maxOf { abs(it.gyroX) }
        if (maxAngularSpeed < minAngularSpeed) return null
        var angle = 0f
        for (i in 1 until samples.size) {
            val dt = (samples[i].timestamp - samples[i - 1].timestamp) / 1000f
            angle += (samples[i].gyroX + samples[i - 1].gyroX) / 2f * dt
        }
        val angleDegrees = Math.toDegrees(angle.toDouble()).toFloat()
        val duration = samples.last().timestamp - samples.first().timestamp
        if (duration < minDurationMs) return null
        return when {
            angleDegrees > angleThresholdDegrees -> { lastGestureTime = timestamp; resetWindow(); GestureType.NEXT_TRACK }
            angleDegrees < -angleThresholdDegrees -> { lastGestureTime = timestamp; resetWindow(); GestureType.PREVIOUS_TRACK }
            else -> null
        }
    }

    override fun reset() { resetWindow(); filteredGyroX = 0f; lastGestureTime = 0L }
    private fun resetWindow() { samples.clear(); gestureStartTime = 0L; idleStartTime = 0L; inGesture = false }
}
