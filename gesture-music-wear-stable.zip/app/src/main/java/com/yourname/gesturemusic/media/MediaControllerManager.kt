package com.yourname.gesturemusic.media

import android.content.ComponentName
import android.content.Context
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.util.Log

class MediaControllerManager(context: Context) {
    companion object { private const val TAG = "MediaControllerManager" }

    private val mediaSessionManager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private var mediaController: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())
    private var callback: MediaController.Callback? = null
    private var stateListener: ((Boolean) -> Unit)? = null

    fun connect() {
        try {
            val sessions = mediaSessionManager.getActiveSessions(
                ComponentName("com.yourname.gesturemusic", "com.yourname.gesturemusic.service.GestureMusicService")
            )
            val activeSession = sessions.firstOrNull()
            if (activeSession != null) {
                mediaController = activeSession
                setupCallback(activeSession)
                Log.d(TAG, "Connected to: ${activeSession.packageName}")
            } else { Log.w(TAG, "No active media session found") }
        } catch (e: SecurityException) { Log.e(TAG, "SecurityException: ${e.message}") }
    }

    fun refreshConnection() { disconnect(); connect() }
    fun disconnect() { mediaController?.unregisterCallback(callback ?: return); mediaController = null; callback = null }
    fun setStateListener(listener: (isPlaying: Boolean) -> Unit) { stateListener = listener }

    fun playPause() {
        val controller = mediaController ?: run { refreshConnection(); return }
        if (controller.playbackState?.state == PlaybackState.STATE_PLAYING)
            controller.transportControls.pause()
        else controller.transportControls.play()
    }
    fun nextTrack() { (mediaController ?: run { refreshConnection(); return }).transportControls.skipToNext() }
    fun previousTrack() { (mediaController ?: run { refreshConnection(); return }).transportControls.skipToPrevious() }
    fun isPlaying(): Boolean = mediaController?.playbackState?.state == PlaybackState.STATE_PLAYING
    fun hasActiveSession(): Boolean = mediaController != null

    private fun setupCallback(controller: MediaController) {
        callback = object : MediaController.Callback() {
            override fun onPlaybackStateChanged(state: PlaybackState?) {
                stateListener?.invoke(state?.state == PlaybackState.STATE_PLAYING)
            }
            override fun onSessionDestroyed() { refreshConnection() }
        }
        controller.registerCallback(callback!!, handler)
        stateListener?.invoke(isPlaying())
    }
}
