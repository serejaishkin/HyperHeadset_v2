// macOS EQMac backend placeholder
