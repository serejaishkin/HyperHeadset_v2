// Linux audio backend placeholder
