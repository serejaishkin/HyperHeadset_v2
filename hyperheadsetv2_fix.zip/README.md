# HyperHeadsetv2 — Tauri Fix

## Быстрая установка (3 шага)

### Шаг 1: Добавить [lib] в корневой Cargo.toml

Откройте `HyperHeadset_v2/Cargo.toml` и добавьте в САМЫЙ КОНЕЦ файла (только один раз!):

```toml
[lib]
path = "src/lib.rs"

[[bin]]
name = "hyperx-ngenuity-open"
path = "src/main.rs"
```

**ВАЖНО:** Не пишите `name = "..."` внутри `[lib]` — Cargo сам создаст имя `hyperx_ngenuity_open` из package name. Если раньше добавляли через `cat >>` и получили дубли — удалите лишние блоки `[lib]` / `[[bin]]`.

### Шаг 2: Патч VoiceConfig (Default)

В файле `src/config.rs` найдите:
```rust
pub struct VoiceConfig {
```

И замените на:
```rust
#[derive(Default)]
pub struct VoiceConfig {
```

### Шаг 3: Скопировать файлы из архива

Распакуйте этот архив ПОВЕРХ вашего репозитория (с заменой файлов).

```bash
cd ~/Documents/GitHub/HyperHeadset_v2
# Распакуйте hyperheadsetv2_fix.zip сюда
```

## Что заменяется

| Файл | Действие |
|------|----------|
| `src/lib.rs` | **Создать** — экспорт модулей для Tauri |
| `src/platform/windows/volume.rs` | **Заменить** — фикс API windows 0.58 |
| `src-tauri/src/main.rs` | **Заменить** — рабочий Tauri backend |
| `src-tauri/Cargo.toml` | **Заменить** — добавлен `[workspace]` |
| `src-tauri/tauri.conf.json` | **Заменить** — убран `withGlobalTauri`, фикс identifier |
| `src-tauri/build.rs` | **Создать** — Tauri build script |
| `src-tauri/icons/icon.png` | **Создать** — placeholder |
| `src-tauri/icons/icon.ico` | **Создать** — placeholder |
| `ui/index.html` | **Создать** — фронтенд |
| `ui/app.js` | **Создать** — логика |
| `ui/styles.css` | **Создать** — тёмная тема |

## Сборка

```bash
cd ~/Documents/GitHub/HyperHeadset_v2/src-tauri
cargo tauri build
```

Без `--release` — Tauri v2 собирает релиз по умолчанию.

## Проверка

1. Запуск без гарнитуры → tray: placeholder-иконка, tooltip «Нет подключения»
2. Подключение гарнитуры → tray: иконка батареи с цифрами
3. Клик «Мьют» в tray → Discord мьют срабатывает
4. Выключение гарнитуры → tray меняется на «Отключено»
